<?php

	require_once("src/Unite.php");
	
	// je crée un nouvel objet à partir de la classe unite

	$d = new Unite();
	echo $d;
	
	$prix = $d->calculPrix();	
	echo "<br>Le produit coute ".$prix." €";
	echo "<br> Le nombre de produit est de :".Produit::$compteur;

?>