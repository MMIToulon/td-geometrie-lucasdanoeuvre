<?php 

// Je crée ma classe grâce à la méthode abstraite afin qu'elle ne puisse pas être instancier

abstract class Produit 
{
	
	// Je déclare mes attributs de la classe Produit
	
   protected $nom_Produit = 0;
   protected $poids_Produit = 10;
   protected $prix_Kilo = 10;
   protected $nbre_Produit = 20;
   protected $prix_Unite = 5;
   
   // Je declare ma fonction constructeur

   public static $compteur = 0 ;
	public function __construct() {
      echo "Construction du produit";

      self::$compteur++;
	}
	
	// On fait appel à la fonction de calcul définit dans Kilo.php

   public abstract function calculPrix();   
}
?>

