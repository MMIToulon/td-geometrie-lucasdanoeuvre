<?php
require_once('Produit.php');

// Je crée ma classe Unite qui est une extension de la classe Produit

class Unite extends Produit{
	
	// Je declare le constructeur de ma fonction

	public function __construct(){
		echo "Création du produit ";
		parent::__construct();
	}
	
	// Je declare ma fonction d'affichage tostring

 	public function __toString(){
 		$text = "<hr> Unite ".
 				"<br> nbre_Produit :".$this->nbre_Produit.
 				"<br> prix_Unite :".$this->prix_Unite."<hr>";
 		return $text;
 	}
	
	// Je declare et execute ma fonction de calcul ici, qui vas faire le calcul du prix total

 	public function calculPrix(){
 		return floor($this->nbre_Produit*$this->prix_Unite);
 	}	
}
?>


