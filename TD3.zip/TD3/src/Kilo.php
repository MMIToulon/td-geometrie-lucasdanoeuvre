<?php
require_once('Produit.php');

// Je crée ma classe Kilo qui est une extension de la classe Produit

class Kilo extends Produit{
	
	// Je declare le constructeur de ma fonction

	public function __construct(){
		echo "Création du produit ";
		parent::__construct();
	}
	
	// Je declare ma fonction d'affichage tostring

 	public function __toString(){
 		$text = "<hr> Kilo ".
 				"<br> poids du Produit :".$this->poids_Produit.
 				"<br> prix au Kilo :".$this->prix_Kilo."<hr>";
 		return $text;
 	}

	// Je declare et execute ma fonction de calcul ici, qui vas faire le calcul du prix total
	
 	public function calculPrix(){
 		return floor($this->prix_Kilo*$this->poids_Produit);
 	}
}



